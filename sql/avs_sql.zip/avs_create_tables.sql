USE [Clinical]
GO

/****** Object:  Table [dbo].[ckoClinicPrefs]    Script Date: 09/12/2014 10:59:33 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[ckoClinicPrefs](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[facilityNo] [varchar](50) NULL,
	[clinicIen] [varchar](50) NULL,
	[layout] [varchar](255) NULL,
	[boilerPlate] [varchar](max) NULL,
	[dateCreated] [datetime] NOT NULL,
	[dateModified] [datetime] NULL,
	[active] [int] NULL,
	[oplock] [int] NULL,
 CONSTRAINT [PK_ckoClinicPrefs] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[ckoClinicPrefs] ADD  CONSTRAINT [DF_ckoClinicPrefs_dateCreated]  DEFAULT (getdate()) FOR [dateCreated]
GO

ALTER TABLE [dbo].[ckoClinicPrefs] ADD  CONSTRAINT [DF_ckoClinicPrefs_active]  DEFAULT ((1)) FOR [active]
GO

ALTER TABLE [dbo].[ckoClinicPrefs] ADD  CONSTRAINT [DF_ckoClinicPrefs_oplock]  DEFAULT ((0)) FOR [oplock]
GO


USE [Clinical]
GO

/****** Object:  Table [dbo].[ckoEncounter]    Script Date: 09/12/2014 11:06:33 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[ckoEncounter](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[encounterCacheId] [int] NULL,
	[encounterDatetime] [decimal](18, 6) NULL,
	[encounterNoteIen] [varchar](50) NULL,
	[visitString] [varchar](50) NULL,
	[locationIen] [varchar](50) NULL,
	[locationName] [varchar](100) NULL,
	[dateCreated] [datetime] NOT NULL,
	[dateModified] [datetime] NULL,
	[active] [int] NULL,
	[oplock] [int] NULL,
 CONSTRAINT [PK_ckoEncounter] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[ckoEncounter] ADD  CONSTRAINT [DF_ckoEncounter_dateCreated]  DEFAULT (getdate()) FOR [dateCreated]
GO

ALTER TABLE [dbo].[ckoEncounter] ADD  CONSTRAINT [DF_ckoEncounter_active]  DEFAULT ((1)) FOR [active]
GO

ALTER TABLE [dbo].[ckoEncounter] ADD  CONSTRAINT [DF_ckoEncounter_oplock]  DEFAULT ((0)) FOR [oplock]
GO


USE [Clinical]
GO

/****** Object:  Table [dbo].[ckoEncounterCache]    Script Date: 09/12/2014 11:09:38 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[ckoEncounterCache](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[facilityNo] [varchar](50) NULL,
	[providerDuz] [varchar](100) NULL,
	[providerName] [varchar](100) NULL,
	[providerTitle] [varchar](200) NULL,
	[patientDfn] [varchar](50) NULL,
	[locationIen] [varchar](20) NULL,
	[locationName] [varchar](100) NULL,
	[encounterDatetime] [decimal](18, 6) NULL,
	[encounterNoteIen] [varchar](20) NULL,
	[instructions] [varchar](max) NULL,
	[customContent] [varchar](max) NULL,
	[fontClass] [varchar](50) NULL,
	[labDateRange] [varchar](50) NULL,
	[sections] [varchar](255) NULL,
	[remoteVaMedications] [varchar](max) NULL,
	[remoteNonVaMedications] [varchar](max) NULL,
	[printServiceDescriptions] [int] NULL,
	[selectedServiceDescriptions] [varchar](255) NULL,
	[charts] [varchar](255) NULL,
	[locked] [int] NULL,
	[printed] [int] NULL,
	[language] [varchar](20) NULL,
	[docType] [varchar](10) NULL,
	[pdfFilename] [varchar](100) NULL,
	[userDuz] [varchar](50) NULL,
	[userName] [varchar](50) NULL,
	[dateCreated] [datetime] NOT NULL,
	[dateModified] [datetime] NULL,
	[active] [int] NULL,
	[oplock] [int] NULL,
 CONSTRAINT [PK_ckoEncounterCache] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[ckoEncounterCache] ADD  CONSTRAINT [DF_ckoEncounterCache_locked]  DEFAULT ((0)) FOR [locked]
GO

ALTER TABLE [dbo].[ckoEncounterCache] ADD  CONSTRAINT [DF_ckoEncounterCache_printed]  DEFAULT ((0)) FOR [printed]
GO

ALTER TABLE [dbo].[ckoEncounterCache] ADD  CONSTRAINT [DF_ckoEncounterCache_dateCreated]  DEFAULT (getdate()) FOR [dateCreated]
GO

ALTER TABLE [dbo].[ckoEncounterCache] ADD  CONSTRAINT [DF_ckoEncounterCache_active]  DEFAULT ((1)) FOR [active]
GO

ALTER TABLE [dbo].[ckoEncounterCache] ADD  CONSTRAINT [DF_ckoEncounterCache_oplock]  DEFAULT ((0)) FOR [oplock]
GO


USE [Clinical]
GO

/****** Object:  Table [dbo].[ckoEncounterProvider]    Script Date: 09/12/2014 11:17:58 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[ckoEncounterProvider](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[encounterId] [int] NULL,
	[providerDuz] [varchar](50) NULL,
	[providerName] [varchar](50) NULL,
	[providerTitle] [varchar](100) NULL,
	[dateCreated] [datetime] NOT NULL,
	[dateModified] [datetime] NULL,
	[active] [int] NULL,
	[oplock] [int] NULL,
 CONSTRAINT [PK_ckoEncounterProvider] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[ckoEncounterProvider] ADD  CONSTRAINT [DF_ckoEncounterProvider_dateCreated]  DEFAULT (getdate()) FOR [dateCreated]
GO

ALTER TABLE [dbo].[ckoEncounterProvider] ADD  CONSTRAINT [DF_ckoEncounterProvider_active]  DEFAULT ((1)) FOR [active]
GO

ALTER TABLE [dbo].[ckoEncounterProvider] ADD  CONSTRAINT [DF_ckoEncounterProvider_oplock]  DEFAULT ((0)) FOR [oplock]
GO


USE [Clinical]
GO

/****** Object:  Table [dbo].[ckoFacilityPrefs]    Script Date: 09/12/2014 11:18:35 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[ckoFacilityPrefs](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[facilityNo] [varchar](50) NULL,
	[timeZone] [varchar](50) NULL,
	[boilerplate] [varchar](max) NULL,
	[header] [varchar](max) NULL,
	[footer] [varchar](max) NULL,
	[pvsFooter] [varchar](max) NULL,
	[tiuTitleIen] [varchar](50) NULL,
	[tiuNoteText] [varchar](max) NULL,
	[serviceDuz] [varchar](50) NULL,
	[kramesEnabled] [int] NULL,
	[servicesEnabled] [int] NULL,
	[medDescriptionsEnabled] [int] NULL,
	[refreshFrequency] [int] NULL,
	[upcomingAppointmentRange] [int] NULL,
	[encountersRange] [int] NULL,
	[orderTimeFrom] [int] NOT NULL,
	[orderTimeThru] [int] NOT NULL,
	[languages] [varchar](255) NULL,
	[dateCreated] [datetime] NOT NULL,
	[dateModified] [datetime] NULL,
	[active] [int] NULL,
	[oplock] [int] NULL,
 CONSTRAINT [PK_ckoFacilityPrefs] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[ckoFacilityPrefs] ADD  CONSTRAINT [DF_ckoFacilityPrefs_kramesEnabled]  DEFAULT ((0)) FOR [kramesEnabled]
GO

ALTER TABLE [dbo].[ckoFacilityPrefs] ADD  CONSTRAINT [DF_ckoFacilityPrefs_servicesEnabled]  DEFAULT ((0)) FOR [servicesEnabled]
GO

ALTER TABLE [dbo].[ckoFacilityPrefs] ADD  CONSTRAINT [DF_ckoFacilityPrefs_medDescriptionsEnabled]  DEFAULT ((0)) FOR [medDescriptionsEnabled]
GO

ALTER TABLE [dbo].[ckoFacilityPrefs] ADD  CONSTRAINT [DF_ckoFacilityPrefs_refreshFrequency]  DEFAULT ((0)) FOR [refreshFrequency]
GO

ALTER TABLE [dbo].[ckoFacilityPrefs] ADD  CONSTRAINT [DF_ckoFacilityPrefs_upcomingAppointmentRange]  DEFAULT ((0)) FOR [upcomingAppointmentRange]
GO

ALTER TABLE [dbo].[ckoFacilityPrefs] ADD  CONSTRAINT [DF_ckoFacilityPrefs_orderTimeFrom]  DEFAULT ((0)) FOR [orderTimeFrom]
GO

ALTER TABLE [dbo].[ckoFacilityPrefs] ADD  CONSTRAINT [DF_ckoFacilityPrefs_orderTimeThru]  DEFAULT ((0)) FOR [orderTimeThru]
GO

ALTER TABLE [dbo].[ckoFacilityPrefs] ADD  CONSTRAINT [DF_ckoFacilityPrefs_dateCreated]  DEFAULT (getdate()) FOR [dateCreated]
GO

ALTER TABLE [dbo].[ckoFacilityPrefs] ADD  CONSTRAINT [DF_ckoFacilityPrefs_active]  DEFAULT ((1)) FOR [active]
GO

ALTER TABLE [dbo].[ckoFacilityPrefs] ADD  CONSTRAINT [DF_ckoFacilityPrefs_oplock]  DEFAULT ((0)) FOR [oplock]
GO


USE [Clinical]
GO

/****** Object:  Table [dbo].[ckoHealthFactors]    Script Date: 09/12/2014 11:19:04 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[ckoHealthFactors](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[stationNo] [varchar](20) NULL,
	[type] [varchar](50) NULL,
	[ien] [varchar](20) NULL,
	[value] [varchar](50) NULL,
	[dateCreated] [datetime] NULL,
	[dateModified] [datetime] NULL,
	[active] [int] NULL,
	[oplock] [int] NULL,
 CONSTRAINT [PK_ckoHealthFactors] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[ckoHealthFactors] ADD  CONSTRAINT [DF_ckoHealthFactors_dateCreated]  DEFAULT (getdate()) FOR [dateCreated]
GO

ALTER TABLE [dbo].[ckoHealthFactors] ADD  CONSTRAINT [DF_ckoHealthFactors_active]  DEFAULT ((1)) FOR [active]
GO

ALTER TABLE [dbo].[ckoHealthFactors] ADD  CONSTRAINT [DF_ckoHealthFactors_oplock]  DEFAULT ((0)) FOR [oplock]
GO


USE [Clinical]
GO

/****** Object:  Table [dbo].[ckoLanguage]    Script Date: 09/12/2014 11:19:54 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[ckoLanguage](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[name] [varchar](50) NULL,
	[abbreviation] [varchar](20) NULL,
	[dateCreated] [datetime] NULL,
	[dateModified] [datetime] NULL,
	[active] [int] NULL,
	[oplock] [int] NULL,
 CONSTRAINT [PK_ckoLanguage] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[ckoLanguage] ADD  CONSTRAINT [DF_ckoLanguage_dateCreated]  DEFAULT (getdate()) FOR [dateCreated]
GO

ALTER TABLE [dbo].[ckoLanguage] ADD  CONSTRAINT [DF_ckoLanguage_active]  DEFAULT ((1)) FOR [active]
GO

ALTER TABLE [dbo].[ckoLanguage] ADD  CONSTRAINT [DF_ckoLanguage_oplock]  DEFAULT ((0)) FOR [oplock]
GO


USE [Clinical]
GO

/****** Object:  Table [dbo].[ckoMedDescriptions]    Script Date: 09/12/2014 11:20:30 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[ckoMedDescriptions](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[ndc] [varchar](50) NULL,
	[shape] [varchar](50) NULL,
	[color] [varchar](50) NULL,
	[frontImprint] [varchar](100) NULL,
	[backImprint] [varchar](100) NULL,
	[dateCreated] [datetime] NOT NULL,
	[dateModified] [datetime] NULL,
	[active] [int] NULL,
	[oplock] [int] NULL,
 CONSTRAINT [PK_ckoMedDescriptions] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[ckoMedDescriptions] ADD  CONSTRAINT [DF_ckoMedDescriptions_dateCreated]  DEFAULT (getdate()) FOR [dateCreated]
GO

ALTER TABLE [dbo].[ckoMedDescriptions] ADD  CONSTRAINT [DF_ckoMedDescriptions_active]  DEFAULT ((1)) FOR [active]
GO

ALTER TABLE [dbo].[ckoMedDescriptions] ADD  CONSTRAINT [DF_ckoMedDescriptions_oplock]  DEFAULT ((0)) FOR [oplock]
GO


USE [Clinical]
GO

/****** Object:  Table [dbo].[ckoProviderPrefs]    Script Date: 09/12/2014 11:21:01 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[ckoProviderPrefs](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[facilityNo] [varchar](50) NULL,
	[providerDuz] [varchar](50) NULL,
	[layout] [varchar](255) NULL,
	[boilerPlate] [text] NULL,
	[dateCreated] [datetime] NOT NULL,
	[dateModified] [datetime] NULL,
	[active] [int] NULL,
	[oplock] [int] NULL,
 CONSTRAINT [PK_ckoProviderPrefs] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[ckoProviderPrefs] ADD  CONSTRAINT [DF_ckoProviderPrefs_dateCreated]  DEFAULT (getdate()) FOR [dateCreated]
GO

ALTER TABLE [dbo].[ckoProviderPrefs] ADD  CONSTRAINT [DF_ckoProviderPrefs_active]  DEFAULT ((1)) FOR [active]
GO

ALTER TABLE [dbo].[ckoProviderPrefs] ADD  CONSTRAINT [DF_ckoProviderPrefs_oplock]  DEFAULT ((0)) FOR [oplock]
GO


USE [Clinical]
GO

/****** Object:  Table [dbo].[ckoPvsClinic]    Script Date: 09/12/2014 11:21:34 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[ckoPvsClinic](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[stationNo] [varchar](20) NULL,
	[clinicIen] [varchar](50) NULL,
	[clinicName] [varchar](255) NULL,
	[inpatient] [int] NULL,
	[printerIen] [varchar](50) NULL,
	[printerName] [varchar](50) NULL,
	[printerIp] [varchar](20) NULL,
	[active] [int] NULL,
	[dateCreated] [datetime] NOT NULL,
	[dateModified] [datetime] NULL,
	[oplock] [int] NULL,
 CONSTRAINT [PK_ckoPvsClinic] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[ckoPvsClinic] ADD  CONSTRAINT [DF_ckoPvsClinic_active]  DEFAULT ((1)) FOR [active]
GO

ALTER TABLE [dbo].[ckoPvsClinic] ADD  CONSTRAINT [DF_ckoPvsClinic_dateCreated]  DEFAULT (getdate()) FOR [dateCreated]
GO

ALTER TABLE [dbo].[ckoPvsClinic] ADD  CONSTRAINT [DF_ckoPvsClinic_oplock]  DEFAULT ((0)) FOR [oplock]
GO


USE [Clinical]
GO

/****** Object:  Table [dbo].[ckoPvsClinicalReminders]    Script Date: 09/12/2014 11:22:06 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[ckoPvsClinicalReminders](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[stationNo] [varchar](50) NULL,
	[reminderIen] [varchar](50) NULL,
	[reminderName] [varchar](255) NULL,
	[dateCreated] [datetime] NOT NULL,
	[dateModified] [datetime] NULL,
	[active] [int] NULL,
	[oplock] [int] NULL,
 CONSTRAINT [PK_ckoClinicalReminders] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[ckoPvsClinicalReminders] ADD  CONSTRAINT [DF_ckoClinicalReminders_dateCreated]  DEFAULT (getdate()) FOR [dateCreated]
GO

ALTER TABLE [dbo].[ckoPvsClinicalReminders] ADD  CONSTRAINT [DF_ckoClinicalReminders_active]  DEFAULT ((1)) FOR [active]
GO

ALTER TABLE [dbo].[ckoPvsClinicalReminders] ADD  CONSTRAINT [DF_ckoClinicalReminders_oplock]  DEFAULT ((0)) FOR [oplock]
GO


USE [Clinical]
GO

/****** Object:  Table [dbo].[ckoPvsPrintLog]    Script Date: 09/12/2014 11:22:44 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[ckoPvsPrintLog](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[clinicId] [int] NULL,
	[patientDfn] [varchar](50) NULL,
	[printed] [int] NULL,
	[active] [int] NULL,
	[dateCreated] [datetime] NOT NULL,
	[dateModified] [datetime] NULL,
	[oplock] [int] NULL,
 CONSTRAINT [PK_ckoPvsPrintLog] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[ckoPvsPrintLog] ADD  CONSTRAINT [DF_ckoPvsPrintLog_active]  DEFAULT ((1)) FOR [active]
GO

ALTER TABLE [dbo].[ckoPvsPrintLog] ADD  CONSTRAINT [DF_ckoPvsPrintLog_dateCreated]  DEFAULT (getdate()) FOR [dateCreated]
GO

ALTER TABLE [dbo].[ckoPvsPrintLog] ADD  CONSTRAINT [DF_ckoPvsPrintLog_oplock]  DEFAULT ((0)) FOR [oplock]
GO


USE [Clinical]
GO

/****** Object:  Table [dbo].[ckoServices]    Script Date: 09/12/2014 11:23:14 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[ckoServices](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[facilityNo] [varchar](50) NULL,
	[name] [varchar](255) NULL,
	[location] [varchar](255) NULL,
	[hours] [varchar](50) NULL,
	[phone] [varchar](50) NULL,
	[comment] [varchar](255) NULL,
	[dateCreated] [datetime] NOT NULL,
	[dateModified] [datetime] NULL,
	[active] [int] NULL,
	[oplock] [int] NULL,
 CONSTRAINT [PK_ckoServices] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[ckoServices] ADD  CONSTRAINT [DF_ckoServices_dateCreated]  DEFAULT (getdate()) FOR [dateCreated]
GO

ALTER TABLE [dbo].[ckoServices] ADD  CONSTRAINT [DF_ckoServices_active]  DEFAULT ((1)) FOR [active]
GO

ALTER TABLE [dbo].[ckoServices] ADD  CONSTRAINT [DF_ckoServices_oplock]  DEFAULT ((0)) FOR [oplock]
GO


USE [Clinical]
GO

/****** Object:  Table [dbo].[ckoStringResources]    Script Date: 09/12/2014 11:23:52 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[ckoStringResources](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[stationNo] [varchar](20) NULL,
	[languageId] [int] NULL,
	[name] [varchar](50) NULL,
	[value] [varchar](max) NULL,
	[dateCreated] [datetime] NULL,
	[dateModified] [datetime] NULL,
	[active] [int] NULL,
	[oplock] [int] NULL,
 CONSTRAINT [PK_ckoStringResources] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[ckoStringResources] ADD  CONSTRAINT [DF_ckoStringResources_dateCreated]  DEFAULT (getdate()) FOR [dateCreated]
GO

ALTER TABLE [dbo].[ckoStringResources] ADD  CONSTRAINT [DF_ckoStringResources_active]  DEFAULT ((1)) FOR [active]
GO

ALTER TABLE [dbo].[ckoStringResources] ADD  CONSTRAINT [DF_ckoStringResources_oplock]  DEFAULT ((0)) FOR [oplock]
GO


USE [Clinical]
GO

/****** Object:  Table [dbo].[ckoTranslations]    Script Date: 09/12/2014 11:24:33 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[ckoTranslations](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[facilityNo] [varchar](50) NOT NULL,
	[source] [varchar](max) NOT NULL,
	[type] [smallint] NOT NULL,
	[translation] [varchar](max) NULL,
	[languageId] [int] NULL,
	[dateCreated] [datetime] NOT NULL,
	[dateModified] [datetime] NULL,
	[active] [int] NULL,
	[oplock] [int] NULL,
 CONSTRAINT [PK_ckoTranslations] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[ckoTranslations] ADD  CONSTRAINT [DF_ckoTranslations_dateCreated]  DEFAULT (getdate()) FOR [dateCreated]
GO

ALTER TABLE [dbo].[ckoTranslations] ADD  CONSTRAINT [DF_ckoTranslations_active]  DEFAULT ((1)) FOR [active]
GO

ALTER TABLE [dbo].[ckoTranslations] ADD  CONSTRAINT [DF_ckoTranslations_oplock]  DEFAULT ((0)) FOR [oplock]
GO


USE [Clinical]
GO

/****** Object:  Table [dbo].[ckoUsageLog]    Script Date: 09/12/2014 11:25:05 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[ckoUsageLog](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[facilityNo] [varchar](50) NULL,
	[userDuz] [varchar](50) NULL,
	[patientDfn] [varchar](50) NULL,
	[locationIens] [varchar](50) NULL,
	[locationNames] [varchar](255) NULL,
	[datetimes] [varchar](100) NULL,
	[action] [varchar](255) NULL,
	[data] [varchar](255) NULL,
	[dateCreated] [datetime] NOT NULL,
	[dateModified] [datetime] NULL,
	[active] [int] NULL,
	[oplock] [int] NULL,
 CONSTRAINT [PK_ckoVistaPrinters] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[ckoUsageLog] ADD  CONSTRAINT [DF_ckoVistaPrinters_dateCreated]  DEFAULT (getdate()) FOR [dateCreated]
GO

ALTER TABLE [dbo].[ckoUsageLog] ADD  CONSTRAINT [DF_ckoVistaPrinters_active]  DEFAULT ((1)) FOR [active]
GO

ALTER TABLE [dbo].[ckoUsageLog] ADD  CONSTRAINT [DF_ckoVistaPrinters_oplock]  DEFAULT ((0)) FOR [oplock]
GO


USE [Clinical]
GO

/****** Object:  Table [dbo].[ckoUserSettings]    Script Date: 09/12/2014 11:25:39 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[ckoUserSettings](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[facilityNo] [varchar](50) NULL,
	[userDuz] [varchar](50) NULL,
	[printerIen] [varchar](50) NULL,
	[printerIp] [varchar](50) NULL,
	[printerName] [varchar](100) NULL,
	[printServiceDescriptions] [int] NULL,
	[isDefaultPrinter] [int] NULL,
	[dateCreated] [datetime] NOT NULL,
	[dateModified] [datetime] NULL,
	[active] [int] NULL,
	[oplock] [int] NULL,
 CONSTRAINT [PK_ckoUserSettings] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[ckoUserSettings] ADD  CONSTRAINT [DF_ckoUserSettings_dateCreated]  DEFAULT (getdate()) FOR [dateCreated]
GO

ALTER TABLE [dbo].[ckoUserSettings] ADD  CONSTRAINT [DF_ckoUserSettings_active]  DEFAULT ((1)) FOR [active]
GO

ALTER TABLE [dbo].[ckoUserSettings] ADD  CONSTRAINT [DF_ckoUserSettings_oplock]  DEFAULT ((0)) FOR [oplock]
GO


USE [Clinical]
GO

/****** Object:  Table [dbo].[vhaSite]    Script Date: 09/12/2014 10:58:05 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[vhaSite](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[visnId] [int] NULL,
	[name] [varchar](200) NULL,
	[location] [varchar](200) NULL,
	[stationNo] [varchar](10) NULL,
	[moniker] [varchar](10) NULL,
	[modality] [varchar](10) NULL,
	[protocol] [varchar](10) NULL,
	[host] [varchar](50) NULL,
	[port] [int] NULL,
	[status] [varchar](20) NULL,
	[dateCreated] [datetime] NOT NULL,
	[dateModified] [datetime] NULL,
	[active] [int] NULL,
	[oplock] [int] NULL,
 CONSTRAINT [PK_vhaSite] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[vhaSite] ADD  CONSTRAINT [DF_vhaSite_dateCreated]  DEFAULT (getdate()) FOR [dateCreated]
GO

ALTER TABLE [dbo].[vhaSite] ADD  CONSTRAINT [DF_vhaSite_active]  DEFAULT ((1)) FOR [active]
GO

ALTER TABLE [dbo].[vhaSite] ADD  CONSTRAINT [DF_vhaSite_oplock]  DEFAULT ((0)) FOR [oplock]
GO


USE [Clinical]
GO

/****** Object:  Table [dbo].[vhaVisn]    Script Date: 09/12/2014 11:26:29 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[vhaVisn](
	[id] [int] IDENTITY(1,1) NOT NULL,
	[name] [varchar](200) NULL,
	[visnNo] [varchar](10) NULL,
	[dateCreated] [datetime] NOT NULL,
	[dateModified] [datetime] NULL,
	[active] [int] NULL,
	[oplock] [int] NULL,
 CONSTRAINT [PK_vhaVisn] PRIMARY KEY CLUSTERED 
(
	[id] ASC
)WITH (PAD_INDEX  = OFF, STATISTICS_NORECOMPUTE  = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS  = ON, ALLOW_PAGE_LOCKS  = ON) ON [PRIMARY]
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[vhaVisn] ADD  CONSTRAINT [DF_vhaVisn_dateCreated]  DEFAULT (getdate()) FOR [dateCreated]
GO

ALTER TABLE [dbo].[vhaVisn] ADD  CONSTRAINT [DF_vhaVisn_active]  DEFAULT ((1)) FOR [active]
GO

ALTER TABLE [dbo].[vhaVisn] ADD  CONSTRAINT [DF_vhaVisn_oplock]  DEFAULT ((0)) FOR [oplock]
GO


