Ext.define('LLVA.AVS.Admin.model.Setting', {
	extend: 'Ext.data.Model',

	fields: [		
		'setting',
        'name',
		'value'
	]
});
