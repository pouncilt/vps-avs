package AVS.Crypt;

import java.io.Console;
import java.util.Scanner;
import org.apache.log4j.varia.NullAppender;
import gov.va.med.crypto.*;

public class AVSCryptMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		org.apache.log4j.BasicConfigurator.configure(new NullAppender());

		boolean isDecrypt = ((args.length > 0) && (args[0].equals("-D")));
		Scanner in = new Scanner(System.in);
		
		if (isDecrypt) {
			System.out.print("Enter encrypyted text : ");
		} else {
			System.out.print("Enter clear text : ");
		}
		
	    String cryptText = in.nextLine();      
		
	    DESPassPhraseEncrypter crypt = new DESPassPhraseEncrypter();

	    if (isDecrypt) {
			String decrypted = crypt.decrypt(cryptText);
			
			if (decrypted != null) {
				System.out.println("decrypted: " + decrypted);
							
		    	String encrypted = crypt.encrypt(decrypted);
				System.out.println("encrypted: " + encrypted);
			} else {
				System.out.println("This is not an Encrypted text!!");
			}
	    	
	    } else {
	    	String encrypted = crypt.encrypt(cryptText);
			System.out.println("encrypted: " + encrypted);
			
			String decrypted = crypt.decrypt(encrypted);
			System.out.println("decrypted: " + decrypted);
	    }
	    
		
	}

}
